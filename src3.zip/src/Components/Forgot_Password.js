import React from 'react';
import './User-Reg.css';

export default class ForgotPassword extends React.Component{
    render(){
        return(
            <div></div>
        );
    }
}