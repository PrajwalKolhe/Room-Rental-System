import React from 'react'
import { BrowserRouter,Routes,Route } from 'react-router-dom'
import Home from './HomePage'
import TenantRegistration from './Tenant-Registration'
import UserLogin from './UserLogin'

const MainMenu = () => {
    return (
        <div>
            <BrowserRouter>
                <Routes>
                    {/* default routing */}
                    <Route path="" element={<Home/>}/>
                    <Route path="/login" element={<UserLogin/>}/>
                    <Route path="/registerTenant" element={<TenantRegistration/>}/>
                </Routes>
            </BrowserRouter>

        </div>
    )
}

export default MainMenu
