import logo from './logo.svg';
import './App.css';
import MainMenu from './Components/MainMenu';

function App() {
  return (
    
    <div className="bg">
      <MainMenu></MainMenu>
     
    </div>
  );
}

export default App;
